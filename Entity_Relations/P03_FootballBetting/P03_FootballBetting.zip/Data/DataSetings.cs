﻿namespace P03_FootballBetting.Data
{
    public class DataSetings
    {
        public const string Connection = @"Server = DESKTOP-AGCLSI5\SQLEXPRESS; Database = FootballBetting; Integrated Security = true;";
    }
}
