﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        Application = 1,
        PDF = 2,
        ZIP = 3
    }
}
