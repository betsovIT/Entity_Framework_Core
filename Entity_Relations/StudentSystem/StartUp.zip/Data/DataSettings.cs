﻿namespace P01_StudentSystem.Data
{
    public static class DataSettings
    {
        public const string ConnectionString = @"Server = DESKTOP-AGCLSI5\SQLEXPRESS; Database = StudentSystem; Integrated Security = true;";
    }
}
