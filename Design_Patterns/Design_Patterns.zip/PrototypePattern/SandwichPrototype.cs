﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrototypePattern
{
    public abstract class SandwichPrototype
    {
        public abstract SandwichPrototype Clone();
    }
}
