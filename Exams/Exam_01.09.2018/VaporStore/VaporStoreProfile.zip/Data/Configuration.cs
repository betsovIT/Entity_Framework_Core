﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-AGCLSI5\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}