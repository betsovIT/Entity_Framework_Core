﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-AGCLSI5\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}
