﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server = DESKTOP-AGCLSI5\SQLEXPRESS; Database = Sales; Integrated Security = true";
    }
}
